money = input("Greeting ")
if "hello" in money.strip().lower():
    print("$0")
elif money.strip().lower()[0] == "h":
    print("$20")
else:
    print("$100")
def main():
    time=input("What time is it? ")
    convertedTime=convert(time)
    if convertedTime <= 8.0 and convertedTime >= 7.0:
        print("breakfast time")
    elif convertedTime <= 13.0 and convertedTime >= 12.0:
        print("lunch time")
    elif convertedTime <= 19.0 and convertedTime >= 18.0:
        print("dinner time")
    else:
        print("")


def convert(time):
    hrsNmins=time.split(":")
    hours=float(hrsNmins[0])
    mins=float(hrsNmins[1])
    mins=mins/60
    return(hours+mins)

if __name__ == "__main__":
    main()
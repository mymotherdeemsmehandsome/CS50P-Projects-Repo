input1=input("What is the Answer to the Great Question of Life, the Universe, and Everything?")
input2=input1.strip()
if input2 == "42":
    print("Yes")
elif input2.lower() == "forty-two":
    print("Yes")
elif input2.lower() == "forty two":
    print("Yes")
else:
    print("No")
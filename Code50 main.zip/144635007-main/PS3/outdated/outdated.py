months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]
while True:
    try:
        day,month,year="","",""
        givendate=input("Date: ").strip()
        if " " and "," in givendate:
            givendate=givendate.replace(","," ").split()
            if givendate[0] in months:
                day=givendate[1]
                month=str(months.index(givendate[0])+1)
                year=givendate[2]
        elif "/" in givendate:
            givendate=givendate.split("/")
            year = givendate[2]
            month = givendate[0]
            day = givendate[1]
        else:
            continue
        if 0<int(day)<32 and 0<int(month)<13:
            break
    except:
        pass
if len(day) <2:
    day="0"+day
if len(month) < 2:
    month="0"+month
print(year+"-"+month+"-"+day)
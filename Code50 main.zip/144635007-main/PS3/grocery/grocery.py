groceryList = {}
while True:
    try:
        item = input("").upper().strip(`)
        if item in groceryList:
            groceryList[item]+=1
        else:
            groceryList[item] = 1
    except:
        break
sortedItems = sorted(list(groceryList.keys()))
for item in sortedItems:
    print(groceryList[item],item)
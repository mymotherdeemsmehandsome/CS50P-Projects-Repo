import sys
from datetime import date
import inflect


def main():
    #datetime(year, month, day, hour, minute, second)
    TODAY = date.today()
    DATE = testDate(getDate())
    c = TODAY - DATE
    p = inflect.engine()

    minutes = c.total_seconds() / 60
    return (p.number_to_words(round(minutes), andword=""))

def getDate():
    return input("Date Of Birth: ")

def testDate(inputDate):
    TODAY = date.today()
    if inputDate == TODAY:
        print(date.fromisoformat(inputDate))
        return date.fromisoformat(inputDate)
    else:
        sys.exit("Invalid Date")

if __name__ == "__main__":
    main()

from seasons import *
import pytest

def test_main_legal():
    assert testDate("1999-01-01") == True
    assert testDate("1999-13-32") == False
'''
    assert validate("127.0.0.1") == True


def test_validate_illegal():
    assert validate("257.27.1.0") == False
    assert validate("-1.27.1.0") == False
    assert validate("257.27.1.10000") == False
    assert validate("255.790.1.0") == False
    assert validate("1.555.555.555") == False


def test_validate_illegal_format():
    assert validate("0....") == False
    assert validate("") == False
    assert validate(",,,,") == False
    assert validate("14") == False

'''

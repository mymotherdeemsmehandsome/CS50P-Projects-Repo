import datetime
from datetime import date
import inflect

class DateToMinutes:
    def __init__(self):
        self.TODAY = date.today()
        self.DATE = getDate()
    @classmethod
    def getDate():
        return input("Date Of Birth: ").split("-")

    @classmethod
    def main():
        #datetime(year, month, day, hour, minute, second)
        dateToMins = DateToMinutes()
        c = dateToMins.TODAY - dateToMins.DATE
        p = inflect.engine()

        minutes = c.total_seconds() / 60
        print('Total difference in minutes: ', p.number_to_words(round(minutes), andword=""))


    if __name__ == "__main__":
        main()

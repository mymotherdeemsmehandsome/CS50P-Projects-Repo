class Jar:
    def __init__(self, capacity=12):
        if capacity >= 0:
            self.capacity = capacity
        else:
            raise ValueError
        self.cookies = 0

    def __str__(self):
        return self.cookies * "🍪"

    def deposit(self, n):
        if n + cookies > capacity:
            raise ValueError
        else:
            cookies += n

    def withdraw(self, n):
        if abs(cookies - 1) > capacity:
            raise ValueError
        else:
            cookies += n

    @property
    def capacity(self):
        ...

    @property
    def size(self):
        ...

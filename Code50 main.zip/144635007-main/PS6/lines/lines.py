import sys

try:
    fileName = sys.argv[1]
    counter = 0
    if ".py" not in fileName:
        sys.exit("Not a python file")
    elif len(sys.argv) > 2:
        sys.exit("Too many arguements")
    else:
        with open(fileName, "r") as file:
            lines = file.readlines()
        for line in lines:
            if not ("" == line.strip() or "#" == line.strip()[0]):
                counter+=1
        print(counter)

except(FileNotFoundError,):
    print("try exited")
    sys.exit(1)

import cowsay, sys, random
words={
    }





#Hi
try:
    print(cowsay.get_output_string(random.choice(cowsay.char_names), sys.argv[1]))
except:
    exit(1)

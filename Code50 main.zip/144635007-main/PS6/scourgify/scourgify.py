import sys
try:
    if len(sys.argv) != 3:
        if len(sys.argv) > 3:
            sys.exit("Too many arguements")
        if len(sys.argv) < 3:
            sys.exit("Too few arguements")
    readFileName = sys.argv[1]
    writeFileName = sys.argv[2]
    if ".csv" not in readFileName or ".csv" not in writeFileName:
        sys.exit("Not a CSV file")
    else:
        with open(readFileName) as readfile:
            for i,line in enumerate(readfile):
                if i == 0:
                    with open(writeFileName, "w") as writefile:
                        writefile.write("first,last,house\n")
                    continue
                else:
                    last, first, house = line.rstrip().split(",")
                    with open(writeFileName, "a") as writefile:
                        writefile.write(f"{first.strip('"').strip(" ")},{last.strip('"').strip(" ")},{house}\n")
        sys.exit(0)
except(FileNotFoundError):
    sys.exit(1)

import sys, tabulate

try:
    if len(sys.argv) != 2:
        if len(sys.argv) > 2:
            sys.exit("Too many arguements")
        if len(sys.argv) < 2:
            sys.exit("Too few arguements")
    fileName = sys.argv[1]
    if ".csv" not in fileName:
        sys.exit("Not a CSV file")
    else:
        pizzas = []

        with open(fileName, 'r') as file:
            for line in file:
                sicilianPizza, small, large = line.rstrip().split(",")
                pizza = {"item": sicilianPizza, "small": small, "large": large}
                pizzas.append(pizza)

        print(tabulate.tabulate(pizzas,headers="firstrow",tablefmt="grid"))
        print()
except(FileNotFoundError):
    sys.exit(1)

import sys,os.path
from PIL import Image, ImageOps

try:
    if len(sys.argv) != 3:
        #print(1)
        sys.exit(1)
    elif not('.jpeg' in sys.argv[1].lower() or '.jpg' in sys.argv[1].lower() or '.png' in sys.argv[1].lower()):
        #print(2.1)
        sys.exit(1)
    extensionIn = os.path.splitext(sys.argv[1])[1]
    extensionOut = os.path.splitext(sys.argv[2])[1]
    if extensionIn != extensionOut:
        #print(3)
        sys.exit(1)
    else:
        shirtName = "shirt.png"
        portraitName = sys.argv[1]
        outputFileName = sys.argv[2]
        with Image.open(shirtName, mode='r', formats=None) as shirt:
            size = shirt.size
            with Image.open(portraitName, mode='r', formats=None) as portrait:
                portrait = ImageOps.fit(portrait, size)#.save(outputFileName)
            #with Image.open(outputFileName, mode='r', formats=None) as portraitFit:
                # if type(portrait) == None:
                #     print ("PortraitFit is empty")
                # if type(shirt) == None:
                #     print ("Shirt is empty")
                portrait.paste(shirt, shirt)
                #shirt.paste(shirt, shirt)
                portrait.save(outputFileName, format=None)
        sys.exit(0)



except(FileNotFoundError):
    #print(0)
    sys.exit(1)

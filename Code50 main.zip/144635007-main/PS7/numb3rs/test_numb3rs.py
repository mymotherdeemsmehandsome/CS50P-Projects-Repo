from numb3rs import validate
import pytest

def test_validate_legal():
    assert validate("0.0.0.0") == True
    assert validate("123.0.1.3") == True
    assert validate("127.0.0.1") == True


def test_validate_illegal():
    assert validate("257.27.1.0") == False
    assert validate("-1.27.1.0") == False
    assert validate("257.27.1.10000") == False
    assert validate("255.790.1.0") == False
    assert validate("1.555.555.555") == False


def test_validate_illegal_format():
    assert validate("0....") == False
    assert validate("") == False
    assert validate(",,,,") == False
    assert validate("14") == False


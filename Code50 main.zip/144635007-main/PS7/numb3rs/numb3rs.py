import re
import sys


def main():
    print(validate(input("IPv4 Address: ")))


def validate(ip):
    addresses = ip.split(".")
    if (len(addresses) != 4):
        return False
    for address in addresses:
        if re.search(r"^[0-9]+$", address):
            if not 0<=int(address)<=255:
                return False
        else:
            return False
    return True


if __name__ == "__main__":
    main()

import re
import sys


def main():
    print(count(input("Text: ")))


def count(s):
    counter = 0
    array = s.split(" ")
    for word in array:
        if re.match(r"um\W*$", word, re.IGNORECASE):
            counter+=1
    return counter

if __name__ == "__main__":
    main()

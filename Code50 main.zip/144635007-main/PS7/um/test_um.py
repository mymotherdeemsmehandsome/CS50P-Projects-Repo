from um import count
import pytest


def test_count_valid():
    assert count("") == 0
    assert count("Um!") == 1
    assert count("Um, who even says um?") == 2


def test_count_invalid():
    assert count("YUmErs") == 0
    assert count("Umbrella") == 0
    assert count("?1?/23umpire") == 0

def test_count_corner_cases():
    assert count("uMuM Um!") == 1
    assert count("MuM ") == 0


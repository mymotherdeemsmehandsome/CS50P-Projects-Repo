import re
import sys


def main():
    print(convert(input("Hours: ")))


def convert(s):
    times = s.split(" ")
    if (len(times) != 5) or (times[2] != "to") or (times[1] != "AM" and times[1] != "PM") or (times[4] != "AM" and times[4] != "PM"):
        raise ValueError()
    firstTime = convertHoursNMins(times[0],times[1])
    secondTime = convertHoursNMins(times[3],times[4])
    return (firstTime + " to " + secondTime)


def convertHoursNMins(a,b):
    hours = -1
    mins = -1
    if ":" in a:
        time = a.split(":")
        if len(time) != 2:
            raise ValueError()
        hours = time[0]
        mins = time[1]
        if not re.search(r"[0-9]+", hours) and re.search(r"[0-9]+", mins):
            raise ValueError()
        hours = int(hours)
        mins = int(mins)
        if not (0<=hours<13 and 0<=mins<60):
            raise ValueError()
    else:
        if not re.search(r"[0-9]+", a):
            raise ValueError()
        hours = int(a)
        mins = 0
        if not 0<=hours<13:
            raise ValueError()
    if b != "AM" and b != "PM":
        raise ValueError()
    if b == "PM":
        hours += 12
    if hours == 12 and b == "AM":
        hours = 0
    if hours == 24 and b == "PM":
        hours = 12
    if hours < 10:
        hours = "0" + str(hours)
    if mins < 10:
        mins = "0" + str(mins)

    return str(hours) + ":" + str(mins)

if __name__ == "__main__":

    main()

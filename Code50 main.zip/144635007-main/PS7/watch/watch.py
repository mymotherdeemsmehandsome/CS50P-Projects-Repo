import re
import sys


def main():
    print(parse(input("HTML: ")))


def parse(s):
    if s == "":
        return "None"
    html = s.strip().split('"')
    link = ""
    address = ""
    for i in range(len(html)):
        #may not be boolean
        if re.search("src\s*=\s*", html[i]):
            link = html[i+1]
    if link == "" or "youtube.com" not in link:
        return "None"
    for i in range(len(link)-1, -1, -1):
        if (link[i] == "/"):
            address = link[i+1:]
            break
    return ("https://youtu.be/" + address)



if __name__ == "__main__":
    main()

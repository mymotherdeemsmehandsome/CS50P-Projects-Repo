playback = input()
print(*(playback.split()), sep='...')
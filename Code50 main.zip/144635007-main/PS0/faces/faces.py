def convert(emoticons: str) -> str:
    print("hello world")
    emoticons = emoticons.replace(":)","🙂")
    emoticons = emoticons.replace(":(","🙁")
    return emoticons


def main():
    emoticons = input()
    print(convert(emoticons))


main()
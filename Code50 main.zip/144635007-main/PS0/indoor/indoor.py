voice = input()
print(voice.lower())
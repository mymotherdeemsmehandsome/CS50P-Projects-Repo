m=int(input())
c=300000000
print(m*(c*c))
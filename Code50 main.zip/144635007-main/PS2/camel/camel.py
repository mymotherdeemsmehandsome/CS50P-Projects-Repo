camel = input("camelCase: ")
python = ""
for i in range(len(camel)):
    if camel[i].isupper() == False:
        python += camel[i]
    else:
        python += "_" + camel[i]
print("snake_case: " + python.lower())
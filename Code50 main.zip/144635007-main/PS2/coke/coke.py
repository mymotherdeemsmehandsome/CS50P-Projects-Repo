amnt_due=50
while amnt_due>0:
    print("Amount Due: ", amnt_due)
    amnt_paid=int(input("Insert Coin: "))

    if amnt_paid==5 or amnt_paid==10 or amnt_paid==25:
        amnt_due-=amnt_paid
print("Change Owed: " + str((-1*amnt_due)))
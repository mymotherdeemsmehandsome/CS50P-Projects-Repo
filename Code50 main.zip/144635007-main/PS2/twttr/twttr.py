inpt = input("Input: ")
output = ""
for i in range(len(inpt)):
    temp = inpt[i].lower()
    if not temp in "aeiou":
        output += inpt[i]
print(output)
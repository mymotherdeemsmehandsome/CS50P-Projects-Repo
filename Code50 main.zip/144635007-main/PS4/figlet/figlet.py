from pyfiglet import Figlet
import sys,random
figlet=Figlet()
if len(sys.argv) == 3 and (sys.argv[1] == "-f" or sys.argv[1] == "--font"):
    try:
        f=sys.argv[2]
        figlet.setFont(font=f)
        s=input("Input: ")
        print("Output:\n",figlet.renderText(s))
    except:
        sys.exit(1)
elif len(sys.argv) == 1:
    f=random.choice(figlet.getFonts())
    figlet.setFont(font=f)
    s=input("Input: ")
    print("Output:\n",figlet.renderText(s))
else:
    sys.exit(1)

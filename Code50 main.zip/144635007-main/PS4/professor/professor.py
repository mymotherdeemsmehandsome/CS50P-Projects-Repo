import random


def main():
    score=0
    level=get_level()
    for i in range(10):
        x = generate_integer(level)
        y = generate_integer(level)
        for j in range(3):
            print(x ,"+", y, "= ",end="")
            try:
                givenans=int(input(""))
                if x+y==givenans:
                    score+=1
                    break
                elif j ==2:
                    print("EEE")
                    print(x ,"+", y, "=",x+y)
                else:
                    print("EEE")
            except(ValueError):
                print("EEE")
                pass
    print("Score:",score)

def get_level():
    while True:
        try:
            level=int(input("Level: "))
            if level == 1 or level == 2 or level == 3:
                return level
        except(ValueError):
            pass

def generate_integer(level):
    if level == 1:
        return random.randrange(0,10)
    if level == 2:
        return random.randrange(10,100)
    if level == 3:
        return random.randrange(100,1000)


if __name__ == "__main__":
    main()

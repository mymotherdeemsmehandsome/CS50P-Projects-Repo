import inflect
names=[]
p = inflect.engine()
while True:
    try:
        name = input("Input: ")
        names.append(name)
    except(KeyboardInterrupt,EOFError):
        break
print("Adieu, adieu, to",p.join(names))

import random
level=0
guess=0
while level<1:
    try:
        level=int(input("Level: "))
        if level >= 1:
            randnumber=random.randrange(1,level+1)
            #print(randnumber)
    except:
        pass
while True:
    try:
        guess=int(input("Guess: "))
        if guess<1:
            pass
        else:
            if guess<randnumber:
                print("Too small!")
            elif guess==randnumber:
                print("Just right!")
                break
            elif guess>randnumber:
                print("Too large!")
    except:
        pass

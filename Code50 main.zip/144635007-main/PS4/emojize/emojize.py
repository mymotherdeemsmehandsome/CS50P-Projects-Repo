import emoji
noEmoji=input("Input: ")
print("Output: "+ emoji.emojize(noEmoji, language='alias'))

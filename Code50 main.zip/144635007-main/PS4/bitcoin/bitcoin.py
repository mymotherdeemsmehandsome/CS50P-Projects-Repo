import json
import requests
import sys
try:
    n=float(sys.argv[1])
except:
    sys.exit("Command-line argument is not a number")

try:
    response = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")
    response = response.json()
    rate = float(response["bpi"]["USD"]["rate"].replace(",",""))
    print(f"${n* rate:,.4f}")
except requests.RequestException:
    sys.exit("Cannot request.")

'''
inpt = input("Input: ")
output = ""
for i in range(len(inpt)):
    temp = inpt[i].lower()
    if not temp in "aeiou":
        output += inpt[i]
print(output)
'''

def main():
    inpt = input("Input: ")
    print(shorten(inpt))


def shorten(word):
    output = ""
    for i in range(len(word)):
        temp = word[i].lower()
        if not temp in "aeiou":
            output += word[i]
    return output


if __name__ == "__main__":
    main()

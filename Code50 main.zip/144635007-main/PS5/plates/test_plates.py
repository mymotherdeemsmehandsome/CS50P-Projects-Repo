from plates import is_valid


def test_plates_beg_alphanum_checks():
    assert is_valid("222222") == False


def test_plates_2_alpha():
    assert is_valid("aa$$$") == False
    assert is_valid("aa...") == False
    assert is_valid("aa   ") == False
    assert is_valid("aa!!!") == False
    assert is_valid("aa???") == False
    assert is_valid("aa@@@") == False


def test_plates_length():
    assert is_valid("H") == False
    assert is_valid("Soupisnotaninstrunmentz") == False


def test_plates_is_alpha():
    assert is_valid("05hid") == False
    assert is_valid("50CS") == False


def test_plates_middle_numbers():
    assert is_valid("AAA222") == True
    assert is_valid("AA2A22") == False


def test_plates_first_num():
    assert is_valid("CS50") == True
    assert is_valid("CS05") == False

'''
def test_plates_edx_community():
    assert is_valid("AB.000") == False# includes punctuation AND first number is zero
    assert is_valid("0A1234") == False# first 2 digits aren't letters AND first number is zero
    assert is_valid("AB00XY") == False# first number is zero AND there is a letter after a number
    assert is_valid("ab 1234") == False# too long AND includes a space
    assert is_valid("00ABCD") == False# first 2 digits aren't letters AND first number is zero
'''

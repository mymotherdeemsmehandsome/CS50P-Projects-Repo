"""
money = input("Greeting ")
if "hello" in money.strip().lower():
    print("$0")
elif money.strip().lower()[0] == "h":
    print("$20")
else:
    print("$100")

"""

def main():
    money = input("Greeting ")
    print("$",value(money),sep="")
    exit(0)


def value(greeting):
    if "hello" in greeting.strip().lower():
        return 0
    elif greeting.strip().lower()[0] == "h":
        return 20
    else:
        return 100


if __name__ == "__main__":
    main()

from bank import value
def test_value_0():
    assert value("hello") == 0
    assert value("Hello") == 0
    assert value("  HeLLo    ") == 0


def test_value_20():
    assert value("hey") == 20
    assert value("hi") == 20
    assert value(" How's iT goInG?   ") == 20


def test_value_100():
    assert value("Greetings!!!") == 100
    assert value("Biographies are weird") == 100
    assert value("Moo") == 100

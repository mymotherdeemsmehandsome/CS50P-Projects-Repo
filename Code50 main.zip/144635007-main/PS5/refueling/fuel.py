'''
def main():
    x=math()
    print(x)


def math():
    while True:
        try:
            x=input("Fraction: ")
            if "/" not in x:
                raise ValueError
            x=x.split("/")
            if "." in x[0] or "." in x[1]:
                raise ValueError
            y=float(x[0])/float(x[1])
            if y >= 0.99 and y<=1.0:
                return "F"
            elif y <= 0.01:
                return "E"
            if y<= 1.0 and y>=0:
                return str(round(y*100))+"%"
        except (ValueError, ZeroDivisionError):
            pass


main()'''

def main():
    userInput=input("Fraction: ")
    percentage=convert(userInput)
    gaugeReading=gauge(percentage)
    print(gaugeReading)

def convert(fraction):
    if "/" not in fraction:
        raise ValueError
    fraction=fraction.split("/")

    if "." in fraction[0] or "." in fraction[1]:
        raise ValueError

    elif int(y[0]) > int(y[1]):
        raise ValueError
    
    y=float(fraction[0])/float(fraction[1])

    if y<= 1.0 and y>=0:
        return int(round(y*100))


def gauge(percentage):
    if percentage >= 99 and percentage<=100:
        return "F"

    elif percentage <= 1:
        return "E"

    elif percentage<= 100 and percentage>=0:
        return str(percentage)+"%"


if __name__ == "__main__":
    main()

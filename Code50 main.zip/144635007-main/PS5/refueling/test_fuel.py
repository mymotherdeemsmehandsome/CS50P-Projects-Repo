from fuel import convert,gauge
import pytest

def test_fuel_convert():
    assert convert("3/5") == 60
    assert convert("1/5") == 20
    assert convert("5/10") == 50


def test_fuel_gauge():
    assert gauge(100) == "F"
    assert gauge(99) == "F"
    assert gauge(1) == "E"
    assert gauge(0) == "E"
    assert gauge(50) == "50%"


def test_fuel_exceptions():
    with pytest.raises(ZeroDivisionError):
        convert("1/0")


    with pytest.raises(ValueError):
        convert("0")

    with pytest.raises(ValueError):
        convert("5/4")

